"""Citation-Grounded QA command-line application."""

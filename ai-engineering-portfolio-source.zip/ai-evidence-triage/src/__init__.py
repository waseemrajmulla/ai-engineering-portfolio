"""AI Evidence Triage command-line application."""

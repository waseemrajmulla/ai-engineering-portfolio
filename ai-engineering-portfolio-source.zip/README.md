# Waseemraj M Mulla — AI Engineering Portfolio

Independent, public-safe AI engineering demos built with synthetic examples. The projects emphasize grounded outputs, evaluation, and human review. They contain no employer code, internal documents, customer data, or confidential company information.

## Projects

### AI Evidence Triage

An evidence-first CI failure investigator. It classifies synthetic failure signatures, cites exact source lines, suggests a review step, and optionally uses an OpenAI-compatible model to summarize the already-extracted evidence.

**Outcome:** converts raw synthetic logs into categorized, line-cited findings and scores the offline classifier with accuracy, precision, recall, and F1. The bundled score is limited to the small synthetic corpus; it is not a production performance claim.

[Open project](ai-evidence-triage/README.md)

### Citation-Grounded QA

A local retrieval-augmented question-answering demo over a small synthetic knowledge base. It ranks document passages, returns short answers with source IDs, and abstains when retrieval confidence is too low.

**Outcome:** makes answer provenance inspectable and measures retrieval hit rate and abstention behavior on labeled synthetic questions.

[Open project](citation-grounded-qa/README.md)

## Run

Each project uses Python 3.11+ and the standard library. See its README for commands and limitations.
